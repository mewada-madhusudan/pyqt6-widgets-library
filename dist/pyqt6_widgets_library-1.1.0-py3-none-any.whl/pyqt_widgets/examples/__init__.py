"""Example applications demonstrating PyQt6 widgets library usage."""

__all__ = [
    'basic_examples',
    'card_showcase',
    'navigation_demo',
    'feedback_demo'
]